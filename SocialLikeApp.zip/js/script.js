
document.addEventListener('DOMContentLoaded', function () {
    const videoFeed = document.getElementById('video-feed');
    const uploadForm = document.getElementById('upload-form');
    const videoUploadInput = document.getElementById('video-upload');
    const videoCount = document.getElementById('video-count');

    // Exemple de vidéos par défaut
    const defaultVideos = [
        'videos/sample1.mp4',
        'videos/sample2.mp4'
    ];

    // Afficher les vidéos par défaut
    function loadDefaultVideos(videos) {
        videos.forEach(videoSrc => {
            const videoElement = document.createElement('video');
            videoElement.src = videoSrc;
            videoElement.controls = true;
            videoFeed.appendChild(videoElement);
        });
    }

    // Charger les vidéos par défaut
    loadDefaultVideos(defaultVideos);

    // Gestion de l'upload des vidéos
    uploadForm.addEventListener('submit', function (event) {
        event.preventDefault();

        const file = videoUploadInput.files[0];
        if (file) {
            const videoURL = URL.createObjectURL(file);
            const videoElement = document.createElement('video');
            videoElement.src = videoURL;
            videoElement.controls = true;
            videoFeed.appendChild(videoElement);

            // Mise à jour du compteur de vidéos
            const currentCount = parseInt(videoCount.textContent);
            videoCount.textContent = currentCount + 1;
        }
    });
});
